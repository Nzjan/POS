import 'package:fluent_ui/fluent_ui.dart';

class Fileconstant {
  static String chefImage = "image/abc/vchef.jpg";
  static Color bgcolor = Colors.red;
}
